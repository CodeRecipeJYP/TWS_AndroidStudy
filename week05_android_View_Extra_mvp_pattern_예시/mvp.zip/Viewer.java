package com.tmanager.myapplication;

/**
 * Created by DoDo on 2017-03-19.
 */

public interface Viewer {
    void showMessage();
    void showProgress();
    void showResult();
}

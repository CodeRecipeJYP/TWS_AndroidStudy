package com.tmanager.myapplication;

/**
 * Created by DoDo on 2017-03-19.
 */

public class ViewerVer1 implements Viewer {
    @Override
    public void showMessage() {

    }

    @Override
    public void showProgress() {

    }

    @Override
    public void showResult() {

    }
}

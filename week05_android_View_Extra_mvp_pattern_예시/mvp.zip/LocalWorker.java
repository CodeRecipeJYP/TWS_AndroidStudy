package com.tmanager.myapplication;

/**
 * Created by DoDo on 2017-03-19.
 */

public class LocalWorker implements Model {
    @Override
    public Data getData(String key) {
        return null;
    }

    @Override
    public void postData(Data data, String key) {

    }

    @Override
    public void putData(Data data, String key) {

    }

    @Override
    public void delete(String key) {

    }
}
